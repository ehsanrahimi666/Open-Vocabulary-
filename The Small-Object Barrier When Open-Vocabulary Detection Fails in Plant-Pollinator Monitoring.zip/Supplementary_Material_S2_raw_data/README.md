# Raw data: annotations and stored detections

Supplementary Material S2 for Rahimi, E. and Jung, C., *The Small-Object Barrier: When
Open-Vocabulary Detection Fails in Plant-Pollinator Monitoring*.

Every score table of the study can be recomputed from these files with `code/evaluate.py`
(Supplementary Material S1). The archive is assembled by `code/package_raw_data.py`, which also
re-scores the stored detections (`verification_report.csv`). `MANIFEST.csv` lists every file with
its size and SHA-256 checksum.

## Layout

```
D1_uav/
    annotations/flowers.csv        one row per flower box in tile-local pixels; clipped = 1 marks
                                   boxes cut by a tile edge (excluded from scoring)
    annotations/labels/*.txt       YOLO labels of the 91 tiles
    images/*.png                   the 91 orthomosaic tiles (640 x 640 px)
    evaluated_images.txt           tiles containing at least one scored flower
    detections/<model>__<prompt>.json
D2_wildflower/
    annotations/*.xml              Pascal VOC annotations of the 290 evaluated images
    evaluated_images.txt           image names (images: https://doi.org/10.34894/U4VQJ6)
    detections/<model>__<prompt>.json
D3_smartphone/
    annotations/data.yaml, annotations/<split>/labels/*.txt   YOLO labels (single class)
    images/<split>/*.jpg           the 333 annotated frames
    evaluated_images.txt
    detections/<model>__<prompt>.json
D4_cameratrap/
    annotations/labels/*.txt       YOLO labels of the 300 evaluated images (class 1 = Apis mellifera)
    evaluated_images.txt           the 300 image names (images: Bjerge et al., 2023)
    detections/<model>__<prompt>.json
object_sizes_per_annotation.csv    size of every measured object (see column `scope`)
detection_file_summary.csv         images, boxes, score range and largest box of every detection file
verification_report.csv            re-scored values compared with the published tables
MANIFEST.csv
```

## Formats

Detection files: `{"detections": {"<image>": [[x0, y0, x1, y1, score], ...], ...}}`, pixel
coordinates of the original image, one file per model and prompt (five models, three prompts).
YOLO labels: `class cx cy w h`, normalised by image width and height. Pascal VOC: one XML file per
image with `xmin`, `ymin`, `xmax`, `ymax` in pixels.

## Licences and sources

Datasets 1 and 3 were collected and annotated by the authors. Dataset 2 is a subset of the
Eindhoven Wildflower Dataset (Schouten et al., 2024; https://doi.org/10.34894/U4VQJ6), distributed
under CC BY-NC 4.0; its annotations are reproduced here for the evaluated images only. Dataset 4 is
a subset of the camera-trap dataset of Bjerge et al. (2023); images are available from the original
source.
